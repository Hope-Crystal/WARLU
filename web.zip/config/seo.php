<?php return array (
  'meta_image' => 'meta.png',
  'meta_keywords' => 'PayEscrow, online transactions, safe online transactions,  escrow service',
  'meta_description' => 'PayEscrow is a secure online payment processing  escrow service.',
  'social_title' => 'Collect money using PayEscrow',
  'social_description' => 'Secure online payment processing  escrow service.',
);