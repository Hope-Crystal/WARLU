<!DOCTYPE html>
<html lang="en" @if(session()->get('rtl') == 1) dir="rtl" @endif >
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    @include('partials.seo')
    <link rel="stylesheet" type="text/css" href="{{asset($themeTrue.'css/bootstrap.min.css')}}"/>
    @stack('css-lib')
    <link rel="stylesheet" type="text/css" href="{{asset($themeTrue.'css/line-awesome.min.css')}}"/>
    <link rel="stylesheet" type="text/css" href="{{asset($themeTrue.'css/nice-select.css')}}"/>
    <link rel="stylesheet" type="text/css" href="{{asset($themeTrue.'css/owl.min.css')}}"/>
    <link rel="stylesheet" type="text/css" href="{{asset($themeTrue.'css/main.css')}}"/>
    <!-- <link rel="stylesheet" type="text/css" href="{{asset($themeTrue.'css/icons.css')}}"/> -->
    <link rel="stylesheet" type="text/css" href="{{asset($themeTrue.'css/animate.css')}}"/>
    @stack('style')
</head>

<body>

<div class="loader">
    <div class="loader-inner">
        <div class="loader-line-wrap">
            <div class="loader-line"></div>
        </div>
        <div class="loader-line-wrap">
            <div class="loader-line"></div>
        </div>
        <div class="loader-line-wrap">
            <div class="loader-line"></div>
        </div>
        <div class="loader-line-wrap">
            <div class="loader-line"></div>
        </div>
        <div class="loader-line-wrap">
            <div class="loader-line"></div>
        </div>
        <br> <br> <br>

        <img src="{{getFile(config('location.logoIcon.path').'logo.png')}}" alt="logo" style="width: 90px; margin-top:-230px;">
    </div>
</div>


<audio id="myNotify">
    <source src="{{asset('assets/admin/css/notify.mp3')}}" type="audio/mpeg">
</audio>

<!--=======Header=======-->


  <!--Start sidebar-wrapper-->
  <div id="wrapper1">
  <div id="sidebar-wrapper" data-simplebar="" data-simplebar-auto-hide="true">

 <div class="brand-logo">
     <a href="{{route('home')}}">
     <img src="{{getFile(config('location.logoIcon.path').'logo.png')}}" alt="logo" style="width: 90px;">
       <!-- <h5 class="logo-text">Warlu</h5> -->
     </a>

      </div>
   <ul class="sidebar-menu do-nicescrol container">
      <!-- <li class="sidebar-header">NAVIGATION</li> -->

      <li class="ml-20 push-notification " id="pushNotificationArea" >
                        <div class="dropdown account-dropdown">
                            <a class="dropdown-toggle" href="javascript:void(0)"  role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
                                <span class="rotate-icon">
                                    <i class="lar la-bell"></i>
                                </span>
                                <span class="badge"  v-cloak>@{{items.length}}</span>
                            </a>
                            <div class="xs-dropdown-menu dropdown-menu dropdown-right">
                                <div class="dropdown-content scrolling-iv">

                                    <a v-for="(item, index) in items" @click.prevent="readAt(item.id, item.description.link)"  href="javascript:void(0)" class="dropdown-item">
                                        <div class="media align-items-center">
                                            <div class="media-icon">
                                                <i :class="item.description.icon" ></i>
                                            </div>
                                            <div class="media-body ml-15">
                                                <h6 class="font-weight-bold" v-cloak v-html="item.description.text"></h6>
                                                <p v-cloak>@{{ item.formatted_date }}</p>
                                            </div>
                                        </div>
                                    </a>

                                </div>
                                <div class="pt-15 pr-15 pb-15 pl-15 d-flex justify-content-center ">
                                    <a class="btn-viewnotification" href="javascript:void(0)" v-if="items.length == 0">@lang('You have no notifications')</a>
                                    <button class="btn-clear " type="button" v-if="items.length > 0" @click.prevent="readAll">@lang('Clear')</button>
                                </div>
                            </div>
                        </div>
                    </li>

      <li><a href="https://warlu.co/">
      <i class="las la-home"></i> <span>@lang('Home') </span>    
      </a></li>

                    <li>    
                    <a  href="{{route('user.home')}}"> <i class="las la-icons"></i> <span>@lang('Dashboard') </span> </a>
                    </li>
                            <li>
                                <a href="{{route('user.makeEscrow')}}">
                                <i class="las la-users"></i> <span>@lang('New Transaction') </span>    
                                </a>
                            </li>
                            <li>
                                <a href="{{route('user.myContactList')}}">
                                <i class="las la-plus"></i> <span>{{trans('Add Your Contact')}} </span>     
                                </a>
                            </li>
                            <li>
                                <a href="{{route('user.myEscrow')}}">
                                <i class="las la-clone"></i> <span> {{trans('My Escrow')}} </span>       
                               </a>
                            </li>

                    <li>
                        <a class="{{menuActive(['user.transaction', 'user.transaction.search'])}}" href="{{route('user.transaction')}}">
                        <i class="las la-money-bill"></i> <span>@lang('Transaction') </span>       
                        
                        </a>
                    </li>

                    <li>
                            <li>
                                <a class="{{menuActive(['user.addFund', 'user.addFund.confirm'])}}" href="{{route('user.addFund')}}">
                                <i class="las la-hand-holding-usd"></i> <span> @lang('Add Fund') </span>       
                                
                                
                               </a>
                            </li>

                            <li>
                                <a class="{{menuActive(['user.fund-history', 'user.fund-history.search'])}}" href="{{route('user.fund-history')}}">
                                <i class="las la-wallet"></i> <span> @lang('Fund Log') </span>       
                                
                               </a>
                            </li>

                    <li>
  
                            <li>
                                <a class="{{menuActive(['user.payout.money','user.payout.preview'])}}" href="{{route('user.payout.money')}}">
                                <i class="las la-landmark"></i> <span>  @lang('Payout Now')</a> </span>       
                                  
                            </li>
                            <li>
                                <a class="{{menuActive(['user.payout.history','payout.history.search'])}}" href="{{route('user.payout.history')}}">
                                    
                                <i class="las la-chart-line"></i> <span>  @lang('Payout Log')</a></span>   
                            </li>


                            <li>
                                <a class="{{menuActive(['user.ticket.list', 'user.ticket.create', 'user.ticket.view'])}}" href="{{route('user.ticket.list')}}"> 
                                <i class="las la-file-invoice"></i> <span> @lang('Support Ticket')</a>  </span>
                            </li>
                        
                            <li>  
                            <a href="{{route('user.twostep.security')}}"> <i class="las la-shield-alt"></i> <span> @lang('2FA Security') </span></a> 
                            </li>
                    
                            <li>
                                
                        <a class="{{menuActive(['user.profile'])}}" href="{{ route('user.profile') }}"> <i class="las la-user-alt"></i> <span> @lang('Profile Settings') </span> </a>
                            </li>
                        
                            <li style="background-color: #d600db; color:#fff;">   <a href="{{ route('logout') }}" onclick="event.preventDefault();
                                                    document.getElementById('logout-form').submit();"> <i class="las la-door-open mr-2"></i>  <span>  <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                                        @csrf
                                                    </form> {{trans('Logout') }}</span>  </a>

                                                
                            </li>

    </ul>
   
   </div>
   <!--End sidebar-wrapper-->


  <!--- Start topbar header -->
<header class="topbar-nav">
 <nav class="navbar navbar-expand fixed-top">
  <ul class="navbar-nav mr-auto align-items-center">
   <a href="{{route('home')}}">
     <img src="{{getFile(config('location.logoIcon.path').'logo.png')}}" alt="logo" style="width: 90px;">
     </a> 



     <li class="nav-item burger" style="margin-left: 20px;">
      <a class="nav-link toggle-menu" href="javascript:void();">
       <i class="icon-menu menu-icon">   </i>
       <i class="las la-bars menu-icon"  style="font-weight: 1000px; font-size:30px;"></i>
     </a>
    </li>
  
    <li class="nav-item">
      <form class="search-bar" style="width: 150%;">
        <input type="text" class="form-control" placeholder="Enter keywords" ">
         <a href="javascript:void();"><i class="icon-magnifier"></i></a>
      </form>
    </li> 

  </ul>
     
  <ul class="navbar-nav align-items-center right-nav-link">

  <span class="hi"  style="font-size: 15px; font-weight:200px"> Hi, <?php echo " $user->username" ?>   </span>  
     

  <li class="nav-item promax">
      <a class="nav-link dropdown-toggle dropdown-toggle-nocaret" data-toggle="dropdown" href="#">
        <span class="user-profile"> <img id="image_preview_container" class="preview-image max-width-200"
        src="{{getFile(config('location.user.path').$user->image)}}"
                                             alt="preview image"></span>
      </a>
    </li>

 
    <li class="transaction" style="background-color: #d600db; padding-top:5px; padding-bottom:px; padding-left:10px; padding-right:10px; border-radius:10px; color:#fff;">
        <a href="{{route('user.makeEscrow')}}">
          <span style="color: #fff ; font-size:12px; font-weight:700">@lang('New Transactions') </span>    
         </a>
    </li>


  </ul>
</nav>
</header>

<!--Start topbar header-->
   <!--End sidebar-wrapper-->

<!---
<header>
    <div class="container">
        <div class="header__wrapper">
            <div class="left__side">
                <div class="logo">
                    <a href="{{route('home')}}">
                        <img src="{{getFile(config('location.logoIcon.path').'logo.png')}}" alt="logo">
                    </a>
                </div>
            </div>
            <div class="right__side">
                <ul class="menu">
      
                     <li><a href="{{route('home')}}">@lang('Home')</a></li> 

                    <li><a href="https://warlu.co/">@lang('Home')</a></li>

                    <li><a  href="{{route('user.home')}}">@lang('Dashboard')</a></li>

                    <li>
                        <a href="javascript:void(0)">{{trans('Escrow')}}</a>
                        <ul class="submenu">
                            <li>
                                <a href="{{route('user.makeEscrow')}}">@lang('Make Escrow')</a>
                            </li>
                            <li>
                                <a href="{{route('user.myContactList')}}">{{trans('Add Your Contact')}}</a>
                            </li>
                            <li>
                                <a href="{{route('user.myEscrow')}}">{{trans('My Escrow')}}</a>
                            </li>
                        </ul>
                    </li>

                    <li>
                        <a class="{{menuActive(['user.transaction', 'user.transaction.search'])}}" href="{{route('user.transaction')}}">@lang('Transaction')</a>
                    </li>

                    <li>
                        <a href="javascript:void(0)">@lang('Fund')</a>
                        <ul class="submenu">
                            <li>
                                <a class="{{menuActive(['user.addFund', 'user.addFund.confirm'])}}" href="{{route('user.addFund')}}">@lang('Add Fund')</a>
                            </li>

                            <li>
                                <a class="{{menuActive(['user.fund-history', 'user.fund-history.search'])}}" href="{{route('user.fund-history')}}">@lang('Fund Log')</a>
                            </li>
                        </ul>
                    </li>

                    <li>
                        <a href="javascript:void(0)">@lang('Payout')</a>
                        <ul class="submenu">
                            <li>
                                <a class="{{menuActive(['user.payout.money','user.payout.preview'])}}" href="{{route('user.payout.money')}}">@lang('Payout Now')</a>
                            </li>
                            <li>
                                <a class="{{menuActive(['user.payout.history','payout.history.search'])}}" href="{{route('user.payout.history')}}">@lang('Payout Log')</a>
                            </li>
                        </ul>
                    </li>


                <li>
                        <a href="javascript:void(0)">{{trans('My Profile')}}</a>
                        <ul class="submenu">
                            <li>
                                <a class="{{menuActive(['user.profile'])}}" href="{{ route('user.profile') }}">@lang('Profile Settings')</a>
                            </li>

                            <li>
                                <a class="{{menuActive(['user.ticket.list', 'user.ticket.create', 'user.ticket.view'])}}"
                                   href="{{route('user.ticket.list')}}">@lang('Support Ticket')</a>
                            </li>

                            <li>
                                <a href="{{route('user.twostep.security')}}">@lang('2FA Security')</a>
                            </li>

                            <li>
                                <a href="{{ route('logout') }}" onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">{{trans('Logout') }}</a>

                                <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                    @csrf
                                </form>
                            </li>

                        </ul>
                    </li>
                </ul>
                <div class="header-bar d-md-none me-2">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>

                <div class="account">

                <ul class="d-flex ml-20">
                    <li class="ml-20 push-notification " id="pushNotificationArea" >
                        <div class="dropdown account-dropdown">
                            <a class="dropdown-toggle" href="javascript:void(0)"  role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
                                <span class="rotate-icon">
                                    <i class="lar la-bell"></i>
                                </span>
                                <span class="badge"  v-cloak>@{{items.length}}</span>
                            </a>
                            <div class="xs-dropdown-menu dropdown-menu dropdown-right">
                                <div class="dropdown-content scrolling-iv">

                                    <a v-for="(item, index) in items" @click.prevent="readAt(item.id, item.description.link)"  href="javascript:void(0)" class="dropdown-item">
                                        <div class="media align-items-center">
                                            <div class="media-icon">
                                                <i :class="item.description.icon" ></i>
                                            </div>
                                            <div class="media-body ml-15">
                                                <h6 class="font-weight-bold" v-cloak v-html="item.description.text"></h6>
                                                <p v-cloak>@{{ item.formatted_date }}</p>
                                            </div>
                                        </div>
                                    </a>

                                </div>
                                <div class="pt-15 pr-15 pb-15 pl-15 d-flex justify-content-center ">
                                    <a class="btn-viewnotification" href="javascript:void(0)" v-if="items.length == 0">@lang('You have no notifications')</a>
                                    <button class="btn-clear " type="button" v-if="items.length > 0" @click.prevent="readAll">@lang('Clear')</button>
                                </div>
                            </div>
                        </div>
                    </li>
                </ul>

                </div>


            </div>
        </div>
    </div>
</header>
<!--=======Header=======-->
	<!--start overlay-->
    <div class="overlay1 toggle-menu"></div>
		<!--end overlay-->
		
</div>
</div>


@yield('content')


@include($theme.'partials.footer')


@stack('loadModal')



<script src="{{asset($themeTrue.'js/jquery-3.6.0.min.js')}}"></script>
<script src="{{asset($themeTrue.'js/popper.min.js')}}"></script>

<script src="{{asset($themeTrue.'js/bootstrap.min.js')}}"></script>
@stack('extra-js')
<script src="{{asset($themeTrue.'js/notiflix-aio-2.7.0.min.js')}}"></script>

<script src="{{asset($themeTrue.'js/nice-select.js')}}"></script>
<script src="{{asset($themeTrue.'js/owl.min.js')}}"></script>
<script src="{{asset($themeTrue.'js/pusher.min.js')}}"></script>
<script src="{{asset($themeTrue.'js/vue.min.js')}}"></script>
<script src="{{asset($themeTrue.'js/axios.min.js')}}"></script>

<script src="{{asset($themeTrue.'js/main.js')}}"></script>

<script src="{{asset($themeTrue.'js/sidebar-menu.js')}}"></script>
<script src="{{asset($themeTrue.'js/app-script.js')}}"></script>

<script src="{{asset($themeTrue.'js/index.js')}}"></script>


@auth
    <script>
        'use strict';
        let pushNotificationArea = new Vue({
            el: "#pushNotificationArea",
            data: {
                items: [],
            },
            beforeMount() {
                this.getNotifications();
                this.pushNewItem();
            },
            methods: {
                getNotifications() {
                    let app = this;
                    axios.get("{{ route('user.push.notification.show') }}")
                        .then(function (res) {
                            console.log(res.data)
                            app.items = res.data;
                        })
                },
                readAt(id, link) {
                    let app = this;
                    let url = "{{ route('user.push.notification.readAt', 0) }}";
                    url = url.replace(/.$/, id);
                    axios.get(url)
                        .then(function (res) {
                            if (res.status) {
                                app.getNotifications();
                                if (link != '#') {
                                    window.location.href = link
                                }
                            }
                        })
                },
                readAll() {
                    let app = this;
                    let url = "{{ route('user.push.notification.readAll') }}";
                    axios.get(url)
                        .then(function (res) {
                            if (res.status) {
                                app.items = [];
                            }
                        })
                },
                pushNewItem() {
                    let app = this;
                    // Pusher.logToConsole = true;
                    let pusher = new Pusher("{{ env('PUSHER_APP_KEY') }}", {
                        encrypted: true,
                        cluster: "{{ env('PUSHER_APP_CLUSTER') }}"
                    });
                    let channel = pusher.subscribe('user-notification.' + "{{ Auth::id() }}");
                    channel.bind('App\\Events\\UserNotification', function (data) {
                        app.items.unshift(data.message);

                        var x = document.getElementById("myNotify");
                        x.play();

                    });
                    channel.bind('App\\Events\\UpdateUserNotification', function (data) {
                        app.getNotifications();
                    });
                }
            }
        });
    </script>
@endauth

@stack('script')
@if (session()->has('success'))
    <script>
        Notiflix.Notify.Success("@lang(session('success'))");
    </script>
@endif

@if (session()->has('error'))
    <script>
        Notiflix.Notify.Failure("@lang(session('error'))");
    </script>
@endif

@if (session()->has('warning'))
    <script>
        Notiflix.Notify.Warning("@lang(session('warning'))");
    </script>
@endif

<script>
    $(document).ready(function () {
        $(".language").find("select").change(function () {
            window.location.href = "{{route('language')}}/" + $(this).val()
        })
    })
</script>


</body>
</html>
